//
//  Inventory.m
//  ImageRecognition
//
//  Created by 鲍利成 on 2018/3/6.
//  Copyright © 2018年 鲍利成. All rights reserved.
//

#import "Inventory.h"

@implementation Inventory
@end
