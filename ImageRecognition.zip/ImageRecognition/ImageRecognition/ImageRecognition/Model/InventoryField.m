//
//  Inventory.m
//  ImageRecognition
//
//  Created by 鲍利成 on 2018/3/6.
//  Copyright © 2018年 鲍利成. All rights reserved.
//

#import "InventoryField.h"

@implementation InventoryField
-(instancetype)initWithField:(NSString *)mField fieldName:(NSString *)mFieldName fieldValue:(NSString *)mFieldValue
{
    self = [super init];
    if (self) {
        _field = mField;
        _fieldName = mFieldName;
        _fieldValue = mFieldValue;
    }
    return self;
}
@end
