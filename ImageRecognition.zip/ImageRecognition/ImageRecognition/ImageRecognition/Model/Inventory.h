//
//  Inventory.h
//  ImageRecognition
//
//  Created by 鲍利成 on 2018/3/6.
//  Copyright © 2018年 鲍利成. All rights reserved.
//

#import <Foundation/Foundation.h>
typedef enum{
    didUpload = 1,
    unUpload
} UploadStatus;
@interface Inventory : NSObject
@property(nonatomic, copy) NSString *field1;
@property(nonatomic, copy) NSString *field2;
@property(nonatomic, copy) NSString *field3;
@property(nonatomic, copy) NSString *field4;
@property(nonatomic, copy) NSString *field5;
@property(nonatomic, copy) NSString *field6;
@property(nonatomic, copy) NSString *field7;
@property(nonatomic, copy) NSString *field8;
@property(nonatomic, copy) NSString *field9;
@property(nonatomic, copy) NSString *field10;
@property(nonatomic, copy) NSString *field11;
@property(nonatomic, copy) NSString *field12;
@property(nonatomic, copy) NSString *field13;
@property(nonatomic, copy) NSString *field14;
@property(nonatomic, copy) NSString *field15;
@property(nonatomic, copy) NSString *field16;
@property(nonatomic, copy) NSString *field17;
@property(nonatomic, copy) NSString *field18;
@property(nonatomic, copy) NSString *field19;
@property(nonatomic, copy) NSString *mark;
@property(nonatomic) UploadStatus status;
@property(nonatomic) NSTimeInterval time;
@end
