//
//  Inventory.h
//  ImageRecognition
//
//  Created by 鲍利成 on 2018/3/6.
//  Copyright © 2018年 鲍利成. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface InventoryField : NSObject
@property(nonatomic) NSInteger fieldId; //排序用
@property(nonatomic, copy) NSString *field;
@property(nonatomic, copy) NSString *fieldName;
@property(nonatomic, copy) NSString *fieldValue;
-(instancetype)initWithField:(NSString *)mField fieldName:(NSString *)mFieldName fieldValue:(NSString *)mFieldValue;
@end
