//
//  MarkPopView.h
//  ImageRecognition
//
//  Created by 鲍利成 on 2018/3/6.
//  Copyright © 2018年 鲍利成. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^CloseActionBlock)(NSString *result);
@interface MarkPopView : UIView
@property(nonatomic, strong) UITextField *markTextField;
@property(nonatomic, strong) UIButton *comfirmButton;
@property(nonatomic, copy) CloseActionBlock closeActionBlock;
@end
