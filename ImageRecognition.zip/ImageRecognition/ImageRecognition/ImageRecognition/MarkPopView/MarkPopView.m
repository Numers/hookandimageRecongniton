//
//  MarkPopView.m
//  ImageRecognition
//
//  Created by 鲍利成 on 2018/3/6.
//  Copyright © 2018年 鲍利成. All rights reserved.
//

#import "MarkPopView.h"
#define DefaultMark  @"DefaultMarkString"
#define LeftAndRightMargin 15.0f
@implementation MarkPopView
-(instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self setBackgroundColor:[UIColor whiteColor]];
        [self.layer setCornerRadius:5.0f];
        [self.layer setMasksToBounds:YES];
        
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 5, frame.size.width, 20)];
        [titleLabel setText:@"备注"];
        [titleLabel setTextAlignment:NSTextAlignmentCenter];
        [self addSubview:titleLabel];
        
        _markTextField = [[UITextField alloc] initWithFrame:CGRectMake(LeftAndRightMargin, 35, frame.size.width - 2 * LeftAndRightMargin, 30)];
        [_markTextField setBorderStyle:UITextBorderStyleRoundedRect];
        [_markTextField setPlaceholder:@"请输入备注"];
        NSString *mark = [[NSUserDefaults standardUserDefaults]  objectForKey:DefaultMark];
        if (mark) {
            [_markTextField setText:mark];
        }
        [self addSubview:_markTextField];
        
        _comfirmButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_comfirmButton setFrame:CGRectMake(0, 0, 125, 30)];
        [_comfirmButton setCenter:CGPointMake(frame.size.width / 2.0f, 100)];
        [_comfirmButton setBackgroundImage:[UIImage imageNamed:@"popButtonBackgroundImage"] forState:UIControlStateNormal];
        [_comfirmButton addTarget:self action:@selector(clickCloseBtn) forControlEvents:UIControlEventTouchUpInside];
        NSAttributedString *title = [[NSAttributedString alloc] initWithString:@"确定" attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14.0f],NSForegroundColorAttributeName:[UIColor whiteColor]}];
        [_comfirmButton setAttributedTitle:title forState:UIControlStateNormal];
        [self addSubview:_comfirmButton];
        
    }
    return self;
}

-(void)clickCloseBtn
{
    if (self.closeActionBlock) {
        self.closeActionBlock(_markTextField.text);
        
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        [userDefaults setObject:_markTextField.text forKey:DefaultMark];
        [userDefaults synchronize];
    }
}
@end
