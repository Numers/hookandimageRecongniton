//
//  AppDelegate.h
//  ImageRecognition
//
//  Created by 鲍利成 on 2017/6/20.
//  Copyright © 2017年 鲍利成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

