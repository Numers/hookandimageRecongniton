//
//  EditViewController.m
//  ImageRecognition
//
//  Created by 鲍利成 on 2018/3/6.
//  Copyright © 2018年 鲍利成. All rights reserved.
//

#import "EditViewController.h"
#import "InventoryField.h"

@interface EditViewController ()
{
    InventoryField *inventoryField;
}
@property(nonatomic, strong) IBOutlet UILabel *titleLabel;
@property(nonatomic, strong) IBOutlet UITextView *textView;
@end

@implementation EditViewController
-(instancetype)initWithInventoryField:(InventoryField *)mInventoryField;
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    self = [storyBoard instantiateViewControllerWithIdentifier:@"EditViewIdentify"];
    if (self) {
        inventoryField = mInventoryField;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [_textView setText:inventoryField.fieldValue];
    [_textView becomeFirstResponder];
    [_titleLabel setText:inventoryField.fieldName];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(IBAction)clickBackBtn:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)clickComfirmBtn:(id)sender
{
    inventoryField.fieldValue = _textView.text;
    [self.navigationController popViewControllerAnimated:YES];
}
@end
