//
//  SDBManager.h
//  ImageRecognition
//
//  Created by 鲍利成 on 2018/3/6.
//  Copyright © 2018年 鲍利成. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabaseAdditions.h"
#import "FMDatabaseQueue.h"

#define kDefaultDBName @"inventory.sqlite"
@interface SDBManager : NSObject
/// 数据库操作对象，当数据库被建立时，会存
@property (nonatomic, readonly) FMDatabase * dataBase;  // 数据库操作对象
+(SDBManager *)defaultDBManager;
@property (nonatomic , strong) NSString * name;
// 关闭数据库
- (void) close;
@end
