//
//  SInventoryDB.m
//  ImageRecognition
//
//  Created by 鲍利成 on 2018/3/6.
//  Copyright © 2018年 鲍利成. All rights reserved.
//

#import "SInventoryDB.h"
#define kInventoryTableName @"SInventory"
@implementation SInventoryDB
#pragma mark - 初始化
- (id) init {
    self = [super init];
    if (self) {
        //========== 首先查看有没有建立message的数据库，如果未建立，则建立数据库=========
        _db = [SDBManager defaultDBManager].dataBase;
    }
    return self;
}

/**
 *  创建数据库
 */
- (void) createDataBase
{
    FMResultSet * set = [_db executeQuery:[NSString stringWithFormat:@"select count(*) from sqlite_master where type ='table' and name = '%@'",kInventoryTableName]];
    
    [set next];
    
    NSInteger count = [set intForColumnIndex:0];
    
    BOOL existTable = !!count;
    
    if (existTable) {
        // TODO:是否更新数据库
        NSLog(@"%@数据库已经存在",kInventoryTableName);
    } else {
        // TODO: 插入新的数据库
        NSString * sql = [NSString stringWithFormat:@"CREATE TABLE %@ (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, field1 VARCHAR(255),field2 VARCHAR(255),field3 VARCHAR(255),field4 VARCHAR(255),field5 VARCHAR(255),field6 VARCHAR(255),field7 VARCHAR(255),field8 VARCHAR(255),field9 VARCHAR(255),field10 VARCHAR(255),field11 VARCHAR(255),field12 VARCHAR(255),field13 VARCHAR(255),field14 VARCHAR(255),field15 VARCHAR(255),field16 VARCHAR(255),field17 VARCHAR(255),field18 VARCHAR(255),field19 VARCHAR(255),mark VARCHAR(255),time TIMESTAMP ,status INTEGER )",kInventoryTableName];
        BOOL res = [_db executeUpdate:sql];
        if (!res) {
            NSLog(@"%@数据库创建失败",kInventoryTableName);
        } else {
            NSLog(@"%@数据库创建成功",kInventoryTableName);
        }
    }

}


/**
 保存发票信息
 
 @param inventory 发票对象
 */
-(BOOL)saveInventory:(Inventory *)inventory
{
    NSMutableString * query = [NSMutableString stringWithFormat:@"INSERT INTO %@",kInventoryTableName];
    NSMutableString * keys = [NSMutableString stringWithFormat:@" ("];
    NSMutableString * values = [NSMutableString stringWithFormat:@" ( "];
    NSMutableArray * arguments = [NSMutableArray arrayWithCapacity:14];
    
    if (inventory.field1) {
        [keys appendString:@"field1,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field1]];
    }
    
    if (inventory.field1) {
        [keys appendString:@"field2,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field2]];
    }
    if (inventory.field1) {
        [keys appendString:@"field3,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field3]];
    }
    if (inventory.field1) {
        [keys appendString:@"field4,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field4]];
    }
    if (inventory.field1) {
        [keys appendString:@"field5,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field5]];
    }
    if (inventory.field1) {
        [keys appendString:@"field6,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field6]];
    }
    if (inventory.field1) {
        [keys appendString:@"field7,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field7]];
    }
    if (inventory.field1) {
        [keys appendString:@"field8,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field8]];
    }
    if (inventory.field1) {
        [keys appendString:@"field9,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field9]];
    }
    if (inventory.field1) {
        [keys appendString:@"field18,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field18]];
    }
    if (inventory.field1) {
        [keys appendString:@"field10,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field10]];
    }
    if (inventory.field1) {
        [keys appendString:@"field11,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field11]];
    }
    if (inventory.field1) {
        [keys appendString:@"field12,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field12]];
    }
    if (inventory.field1) {
        [keys appendString:@"field13,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field13]];
    }
    if (inventory.field1) {
        [keys appendString:@"field14,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field14]];
    }
    if (inventory.field1) {
        [keys appendString:@"field19,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field19]];
    }
    if (inventory.field1) {
        [keys appendString:@"field15,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field15]];
    }
    if (inventory.field1) {
        [keys appendString:@"field16,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field16]];
    }
    if (inventory.field1) {
        [keys appendString:@"field17,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.field17]];
    }
    
    if (inventory.mark) {
        [keys appendString:@"mark,"];
        [values appendString:@"?,"];
        [arguments addObject:[NSString stringWithFormat:@"%@",inventory.mark]];
    }
    
    [keys appendString:@"status,"];
    [values appendString:@"?,"];
    [arguments addObject:[NSString stringWithFormat:@"%ld",(long)inventory.status]];
    
    [keys appendString:@"time,"];
    [values appendString:@"?,"];
    [arguments addObject:[NSString stringWithFormat:@"%lf",inventory.time]];
    
    [keys appendString:@")"];
    [values appendString:@")"];
    [query appendFormat:@" %@ VALUES%@",
     [keys stringByReplacingOccurrencesOfString:@",)" withString:@")"],
     [values stringByReplacingOccurrencesOfString:@",)" withString:@")"]];
    NSLog(@"%@",query);
    
    BOOL flag = [_db executeUpdate:query withArgumentsInArray:arguments];
    flag?NSLog(@" SInventory 插入一条数据 成功"):NSLog(@"SInventory 插入一条数据 失败");
    return flag;
}

-(NSArray *)selectInventorysWithStatus:(UploadStatus)status
{
    NSString * query = [NSString stringWithFormat:@"SELECT * FROM %@ WHERE status=%ld",kInventoryTableName,(long)status];
    FMResultSet * rs = [_db executeQuery:query];
    NSMutableArray * array = [NSMutableArray arrayWithCapacity:[rs columnCount]];
    while ([rs next]) {
        Inventory *inventory = [[Inventory alloc] init];
        inventory.field1 = [rs stringForColumn:@"field1"];
        inventory.field2 = [rs stringForColumn:@"field2"];
        inventory.field3 = [rs stringForColumn:@"field3"];
        inventory.field4 = [rs stringForColumn:@"field4"];
        inventory.field5 = [rs stringForColumn:@"field5"];
        inventory.field6 = [rs stringForColumn:@"field6"];
        inventory.field7 = [rs stringForColumn:@"field7"];
        inventory.field8 = [rs stringForColumn:@"field8"];
        inventory.field9 = [rs stringForColumn:@"field9"];
        inventory.field10 = [rs stringForColumn:@"field10"];
        inventory.field11 = [rs stringForColumn:@"field11"];
        inventory.field12 = [rs stringForColumn:@"field12"];
        inventory.field13 = [rs stringForColumn:@"field13"];
        inventory.field14 = [rs stringForColumn:@"field14"];
        inventory.field15 = [rs stringForColumn:@"field15"];
        inventory.field16 = [rs stringForColumn:@"field16"];
        inventory.field17 = [rs stringForColumn:@"field17"];
        inventory.field18 = [rs stringForColumn:@"field18"];
        inventory.field19 = [rs stringForColumn:@"field19"];
        inventory.mark = [rs stringForColumn:@"mark"];
        inventory.status = (UploadStatus)[rs intForColumn:@"status"];
        inventory.time = [rs doubleForColumn:@"time"];
        [array addObject:inventory];
    }
    [rs close];
    return array;
}

-(void)mergeInventorysStatus:(UploadStatus)status
{
    NSString * query = [NSString stringWithFormat:@"UPDATE %@ SET status = '%d'",kInventoryTableName,(int)status];
    NSInteger resultCount=[_db executeUpdate:query];
    NSLog(@"修改 %ld 条数据 ",(long)resultCount);
}
@end
