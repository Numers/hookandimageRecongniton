//
//  SInventoryDB.h
//  ImageRecognition
//
//  Created by 鲍利成 on 2018/3/6.
//  Copyright © 2018年 鲍利成. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SDBManager.h"
#import "Inventory.h"

@interface SInventoryDB : NSObject
{
    FMDatabase * _db;
}
/**
 *  创建数据库
 */
- (void) createDataBase;


/**
 保存发票信息

 @param inventory 发票对象
 */
-(BOOL)saveInventory:(Inventory *)inventory;


/**
 查询特定状态的发票信息

 @param status 发票是否上传状态
 @return 发票列表
 */
-(NSArray *)selectInventorysWithStatus:(UploadStatus)status;


/**
 改变所有发票的状态

 @param status 发票状态
 */
-(void)mergeInventorysStatus:(UploadStatus)status;
@end
