//
//  ExportExcel.m
//  ImageRecognition
//
//  Created by 鲍利成 on 2018/3/6.
//  Copyright © 2018年 鲍利成. All rights reserved.
//

#import "ExportExcel.h"
#import "AppUtils.h"
#import "LibXL/libxl.h"
#import "Inventory.h"

@implementation ExportExcel
+(instancetype)shareManager
{
    static ExportExcel *exportExcelManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        exportExcelManager = [[ExportExcel alloc] init];
    });
    return exportExcelManager;
}

-(BOOL)exportDataWithInventorys:(NSArray *)inventorys
{
    BOOL success = false;
    if (inventorys && inventorys.count > 0) {
        BookHandle book = xlCreateBook(); // use xlCreateXMLBook() for working with xlsx files
        
        SheetHandle sheet = xlBookAddSheet(book, "Sheet1", NULL);
        //第一个参数代表插入哪个表，第二个是第几行（默认从0开始），第三个是第几列（默认从0开始）
        for (int i = 0; i < 19; i++) {
            NSString *field = [NSString stringWithFormat:@"field%d",i+1];
            if ([self.delegate respondsToSelector:@selector(fieldNameWithField:)]) {
                const char *fieldName = [[self.delegate fieldNameWithField:field] cStringUsingEncoding:NSUTF8StringEncoding];
                xlSheetWriteStr(sheet, 1, i, fieldName, 0);
            }else{
                const char *fieldName = [field cStringUsingEncoding:NSUTF8StringEncoding];
                xlSheetWriteStr(sheet, 1, i, fieldName, 0);
            }
        }
        xlSheetWriteStr(sheet, 1, 19, "备注", 0);
        
        int k = 2;
        for (Inventory *inventory in inventorys) {
            for (int j = 0; j < 19; j ++) {
                NSString *field = [NSString stringWithFormat:@"field%d",j+1];
                const char *fieldValue = [[inventory valueForKey:field] cStringUsingEncoding:NSUTF8StringEncoding];
                xlSheetWriteStr(sheet, k, j,fieldValue, 0);
            }
            const char *markValue = [inventory.mark cStringUsingEncoding:NSUTF8StringEncoding];
            xlSheetWriteStr(sheet, k, 19,markValue, 0);
            k++;
        }
        
        NSString *documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES) objectAtIndex:0];
        NSString *dateString = [AppUtils dateStringFromDate:[NSDate date]];
        NSString *filename = [documentPath stringByAppendingPathComponent:[NSString stringWithFormat:@"inventory_%@.xls",dateString]];
        NSLog(@"filepath--%@",filename);
        
        success = xlBookSave(book, [filename UTF8String]);
        
        xlBookRelease(book);
    }else{
        [AppUtils showInfo:@"当前无新识别发票信息"];
    }
    return success;
}
@end
