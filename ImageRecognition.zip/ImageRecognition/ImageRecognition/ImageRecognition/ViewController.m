//
//  ViewController.m
//  ImageRecognition
//
//  Created by 鲍利成 on 2017/6/20.
//  Copyright © 2017年 鲍利成. All rights reserved.
//

#import "ViewController.h"
#import "AppUtils.h"
#import "InventoryField.h"
#import "Inventory.h"
#import "SInventoryDB.h"
#import <AipOcrSdk/AipOcrSdk.h>
#import "GCDWebUploader.h"
#import "ZJAnimationPopView.h"
#import "MarkPopView.h"
#import "ExportExcel.h"

#import "EditViewController.h"

@interface ViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate,GCDWebUploaderDelegate,UITableViewDelegate,UITableViewDataSource,ExportExcelProtocol>
{
    NSString *accessToken;
    NSArray *fieldNames;
    
    NSMutableArray *inventoryList;
    
    ZJAnimationPopView *popView;
    GCDWebUploader* _webServer;
}

@property(nonatomic, strong) IBOutlet UITableView *tableView;
@property(nonatomic, strong) IBOutlet UILabel *titleLabel;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    inventoryList = [NSMutableArray array];
    fieldNames = @[@"票号",@"编码",@"开票日期",@"货物或应税劳务名称",@"规格型号",@"单位",@"数量",@"单价",@"金额",@"税率",@"税额",@"合计金额",@"合计税额",@"价税合计(大写)",@"价税合计(小写)",@"销贷单位名称",@"纳税人识别号",@"地址、电话",@"开户行及账号"];
    
    [ExportExcel shareManager].delegate = self;
    
    [_tableView setTableFooterView:[UIView new]];
    [self requestAccessToken:@"HAc2bsdUS7i3yPy1zxVomEK8" secretKey:@"Ra7lxm893eV18PkS8RVkj7KeS1sFAiyE"];
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES];
    [_tableView reloadData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma -mark private functions
- (NSData *)jpgDataWithImage:(UIImage *)image sizeLimit:(NSUInteger)maxSize {
    CGFloat compressionQuality = 1.0;
    NSData *imageData = nil;
    
    int i = 0;
    do{
        imageData = UIImageJPEGRepresentation(image, compressionQuality);
        compressionQuality -= 0.1;
        i += 1;
    }while(i < 3 && imageData.length > maxSize);
    return imageData;
}

- (NSString *)base64Escape:(NSString *)string {
    NSCharacterSet *URLBase64CharacterSet = [[NSCharacterSet characterSetWithCharactersInString:@"/+=\n"] invertedSet];
    return [string stringByAddingPercentEncodingWithAllowedCharacters:URLBase64CharacterSet];
}

-(NSString *)adaptFieldName:(NSString *)fieldName
{
    NSString *adaptName = nil;
    for(NSInteger i = 0; i < fieldNames.count; i++){
        NSString *tempFieldName = [NSString stringWithFormat:@"field%ld",i+1];
        if ([fieldName isEqualToString:tempFieldName]) {
            adaptName = [fieldNames objectAtIndex:i];
            break;
        }
    }
    return adaptName;
}

- (NSString *)wwwFormWithDictionary:(NSDictionary *)dict {
    NSMutableString *result = [[NSMutableString alloc] init];
    if (dict != nil) {
        for (NSString *key in dict) {
            if (result.length)
                [result appendString:@"&"];
            [result appendString:[self base64Escape:key]];
            [result appendString:@"="];
            [result appendString:[self base64Escape:dict[key]]];
        }
    }
    return result;
}

-(void)requestAccessToken:(NSString *)apikey secretKey:(NSString *)secretKey
{
    NSString *urlString = [NSString stringWithFormat:@"https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=%@&client_secret=%@",apikey,secretKey];
    NSURL *url = [NSURL URLWithString: urlString];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL: url cachePolicy: NSURLRequestUseProtocolCachePolicy timeoutInterval: 10];
    [request setHTTPMethod: @"POST"];
    [NSURLConnection sendAsynchronousRequest: request
                                       queue: [NSOperationQueue mainQueue]
                           completionHandler: ^(NSURLResponse *response, NSData *data, NSError *error){
                               [AppUtils hiddenLoadingInView:self.view];
                               if (error) {
                                   NSLog(@"Httperror: %@%ld", error.localizedDescription, error.code);
                                   [AppUtils showInfo:error.localizedDescription];
                               } else {
                                   id resp = [NSJSONSerialization JSONObjectWithData:data
                                                                             options:NSJSONReadingAllowFragments
                                                                               error:nil];
                                   accessToken = [resp objectForKey:@"access_token"];
                                   
                               }
                           }];
}

-(void)request: (NSString*)httpUrl withHttpArg: (NSString*)HttpArg  {
    if (accessToken == nil) {
        [AppUtils showInfo:@"未获取accessToken"];
        return;
    }
    NSURL *url = [NSURL URLWithString: httpUrl];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL: url cachePolicy: NSURLRequestUseProtocolCachePolicy timeoutInterval: 10];
    [request setHTTPMethod: @"POST"];
    [request addValue: @"application/x-www-form-urlencoded" forHTTPHeaderField: @"Content-Type"];
    NSData *data = [HttpArg dataUsingEncoding: NSUTF8StringEncoding];
    [request setHTTPBody: data];
    
    [AppUtils showLoadingInView:self.view];
    [NSURLConnection sendAsynchronousRequest: request
                                       queue: [NSOperationQueue mainQueue]
                           completionHandler: ^(NSURLResponse *response, NSData *data, NSError *error){
                               [AppUtils hiddenLoadingInView:self.view];
                               if (error) {
                                   NSLog(@"Httperror: %@%ld", error.localizedDescription, error.code);
                                   [AppUtils showInfo:error.localizedDescription];
                               } else {
                                   NSInteger responseCode = [(NSHTTPURLResponse *)response statusCode];
                                   
                                   id resp = [NSJSONSerialization JSONObjectWithData:data
                                                                             options:NSJSONReadingAllowFragments
                                                                               error:nil];
                                   
                                   if ([resp isKindOfClass:[NSDictionary class]]) {
                                       NSLog(@"%@",(NSDictionary *)resp);
                                   }
                                   
                                   NSInteger errorNo = [[resp objectForKey:@"error_code"] integerValue];
                                   if (errorNo != 0) {
                                       [AppUtils showInfo:[resp objectForKey:@"error_msg"]];
                                       return;
                                   }
                                   NSDictionary *retData = resp[@"data"];
                                   BOOL isStructured = [retData objectForKey:@"isStructured"];
                                   if (isStructured) {
                                       if (inventoryList && inventoryList.count > 0) {
                                           [inventoryList removeAllObjects];
                                       }
                                       NSArray *ret = [retData objectForKey:@"ret"];
                                       for (NSDictionary *wordDic in ret) {
                                           NSString *field = [wordDic objectForKey:@"word_name"];
                                           NSString *fieldName = [self adaptFieldName:field];
                                           NSString *word = [wordDic objectForKey:@"word"];
                                           
                                           InventoryField *inventoryField = [[InventoryField alloc] initWithField:field fieldName:fieldName fieldValue:word];
                                           inventoryField.fieldId = [fieldNames indexOfObject:fieldName];
                                           [inventoryList addObject:inventoryField];
                                       }
                                       
                                       [inventoryList sortUsingComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
                                           InventoryField *field1 = (InventoryField *)obj1;
                                           InventoryField *field2 = (InventoryField *)obj2;
                                           if (field1.fieldId > field2.fieldId) {
                                               return NSOrderedDescending;
                                           }
                                           
                                           return NSOrderedAscending;
                                       }];
                                       [_tableView reloadData];
                                   }
                               }
                           }];
}

- (NSString *)urlencode:(NSString*) data {
    NSMutableString *output = [NSMutableString string];
    const unsigned char *source = [data UTF8String];
    int sourceLen = strlen((const char *)source);
    for (int i = 0; i < sourceLen; ++i) {
        const unsigned char thisChar = source[i];
        if (thisChar == ' '){
            [output appendString:@"+"];
        } else if (thisChar == '.' || thisChar == '-' || thisChar == '_' || thisChar == '~' ||
                   (thisChar >= 'a' && thisChar <= 'z') ||
                   (thisChar >= 'A' && thisChar <= 'Z') ||
                   (thisChar >= '0' && thisChar <= '9')) {
            [output appendFormat:@"%c", thisChar];
        } else {
            [output appendFormat:@"%%%02X", thisChar];
        }
    }
    return output;
}

-(void)imageRecognition:(UIImage *)image
{
    NSString *httpUrl = [NSString stringWithFormat:@"https://aip.baidubce.com/rest/2.0/solution/v1/iocr/recognise?access_token=%@",accessToken];
    NSMutableDictionary *options = [NSMutableDictionary dictionaryWithObject:@"6892a4e25a5fb8766d317bb9da393d26" forKey:@"templateSign"];
    NSData *imageData = [self jpgDataWithImage:image sizeLimit:512000];
    [options setObject:[imageData base64EncodedStringWithOptions:0] forKey:@"image"];
    NSString* querydata = [self wwwFormWithDictionary:options];
    [self request: httpUrl withHttpArg: querydata];

}
#pragma -mark ButtonEvent
-(IBAction)clickCameraBtn:(id)sender
{
    UIViewController *vc = [AipGeneralVC ViewControllerWithHandler:^(UIImage *image) {
        [self.navigationController dismissViewControllerAnimated:YES completion:^{
            [self imageRecognition:image];
        }];
    }];
    
    [self.navigationController presentViewController:vc animated:YES completion:^{
        
    }];
}

-(IBAction)clickPhotoBtn:(id)sender
{
    UIImagePickerController *imgPicker=[[UIImagePickerController alloc]init];
    [imgPicker setSourceType:UIImagePickerControllerSourceTypePhotoLibrary];
    [imgPicker setDelegate:self];
    [imgPicker setAllowsEditing:YES];
    [self.navigationController presentViewController:imgPicker animated:YES completion:^{
        
    }];
}

-(IBAction)clickUploadBtn:(id)sender
{
    SInventoryDB *inventorydb = [[SInventoryDB alloc] init];
    NSArray *inventorys = [inventorydb selectInventorysWithStatus:unUpload];
    if (inventorys && inventorys.count == 0) {
        [AppUtils showInfo:@"当前无新识别发票信息"];
        return;
    }
    BOOL success = [[ExportExcel shareManager] exportDataWithInventorys:inventorys];
    if (success) {
        [AppUtils showInfo:@"导出excel成功"];
        [inventorydb mergeInventorysStatus:didUpload];
        
        if (_webServer == nil) {
            NSString* documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
            _webServer = [[GCDWebUploader alloc] initWithUploadDirectory:documentsPath];
            _webServer.delegate = self;
            _webServer.allowHiddenItems = YES;
            if ([_webServer start]) {
                NSLog(@"%@,%@",_webServer.bonjourServerURL, [NSString stringWithFormat:NSLocalizedString(@"GCDWebServer running locally on port %i", nil), (int)_webServer.port]);
            } else {
                NSLog(@"%@",NSLocalizedString(@"GCDWebServer not running!", nil)) ;
            }
        }else{
            if (![_webServer isRunning]) {
                if ([_webServer start]) {
                    NSLog(@"%@,%@",_webServer.bonjourServerURL, [NSString stringWithFormat:NSLocalizedString(@"GCDWebServer running locally on port %i", nil), (int)_webServer.port]);
                } else {
                    NSLog(@"%@",NSLocalizedString(@"GCDWebServer not running!", nil)) ;
                }
            }
        }
    }else{
        [AppUtils showInfo:@"导出excel失败，再试一次"];
    }
    
}

-(IBAction)clickSaveBtn:(id)sender
{
    if (inventoryList && inventoryList.count == 0){
        [AppUtils showInfo:@"请先选取或拍摄一张发票照片"];
        return;
    }
    
    if (popView) {
        [popView dismiss];
        popView = nil;
    }
    
    MarkPopView *markPopView = [[MarkPopView alloc] initWithFrame:CGRectMake(0, 0, 180, 135)];
    popView = [[ZJAnimationPopView alloc] initWithCustomView:markPopView popStyle:ZJAnimationPopStyleScale dismissStyle:ZJAnimationDismissStyleScale];
    // 2.设置属性，可不设置使用默认值，见注解
    // 2.1 显示时点击背景是否移除弹框
    popView.isClickBGDismiss = YES;
    // 2.2 显示时背景的透明度
    popView.popBGAlpha = 0.5f;
    // 2.3 显示时是否监听屏幕旋转
    popView.isObserverOrientationChange = YES;
    
    // 2.6 显示完成回调
    popView.popComplete = ^{
        NSLog(@"显示完成");
    };
    // 2.7 移除完成回调
    popView.dismissComplete = ^{
        NSLog(@"移除完成");
    };
    
    __weak typeof(popView) weakPopView = popView;
    [markPopView setCloseActionBlock:^(NSString *result) {
        if (inventoryList && inventoryList.count > 0) {
            Inventory *inventory = [[Inventory alloc] init];
            for (InventoryField *inventoryField in inventoryList) {
                [inventory setValue:inventoryField.fieldValue forKey:inventoryField.field];
            }
            inventory.status = unUpload;
            inventory.time = [[NSDate date] timeIntervalSince1970];
            inventory.mark = result;
            SInventoryDB *inventorydb = [[SInventoryDB alloc] init];
            BOOL success = [inventorydb saveInventory:inventory];
            if (success) {
                [inventoryList removeAllObjects];
                [_tableView reloadData];
            }else{
                [AppUtils showInfo:@"保存失败，请再试一次"];
            }
        }
        
        [weakPopView dismiss];
    }];
    
    [popView pop];
    
}
#pragma mark ----------图片选择完成-------------
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage  *picture= [info objectForKey:@"UIImagePickerControllerEditedImage"];
    [self.navigationController dismissViewControllerAnimated:YES completion:^{
        [self imageRecognition:picture];
    }];
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:^{
        //
    }];
}

#pragma -mark UITableViewDelegate | UITableViewDatasource
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60.0f;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return inventoryList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"InventoryCellIdentify"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"InventoryCellIdentify"];
        [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    }
    
    InventoryField *inventoryField = [inventoryList objectAtIndex:indexPath.row];
    [cell.textLabel setText:inventoryField.fieldName];
    [cell.detailTextLabel setText:inventoryField.fieldValue];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    InventoryField *inventoryField = [inventoryList objectAtIndex:indexPath.row];
    EditViewController *editVC = [[EditViewController alloc] initWithInventoryField:inventoryField];
    [self.navigationController pushViewController:editVC animated:YES];
}

#pragma -mark ExportExcelProtocl
-(NSString *)fieldNameWithField:(NSString *)field
{
    return [self adaptFieldName:field];
}

#pragma -mark GCDWebUploaderDelegate
- (void)webUploader:(GCDWebUploader*)uploader didUploadFileAtPath:(NSString*)path {
    NSLog(@"[UPLOAD] %@", path);
    
}

- (void)webUploader:(GCDWebUploader*)uploader didMoveItemFromPath:(NSString*)fromPath toPath:(NSString*)toPath {
    NSLog(@"[MOVE] %@ -> %@", fromPath, toPath);
}

- (void)webUploader:(GCDWebUploader*)uploader didDeleteItemAtPath:(NSString*)path {
    NSLog(@"[DELETE] %@", path);
}

- (void)webUploader:(GCDWebUploader*)uploader didCreateDirectoryAtPath:(NSString*)path {
    NSLog(@"[CREATE] %@", path);
}

- (void)webServerDidCompleteBonjourRegistration:(GCDWebServer*)server
{
    NSLog(@"请在浏览器中键入%@访问",server.bonjourServerURL);
    NSString *desc = [NSString stringWithFormat:@"请在浏览器中键入%@访问",server.bonjourServerURL];
    [_titleLabel setText:server.bonjourServerURL.absoluteString];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"提示" message:desc delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil, nil];
    [alertView show];
}
@end
